export const API = {
  EXCELDATA: "/stg_trn_data/",
  FETCHERRORDATA: "/err_trn_data_tab/",
  UPDATEERRORDATA: "/delete_err_trn/",
  GETCLASSDATA: "/lov_item_dtl/",
  GETLOCATIONDATA: "/location_validation/",
  FETCHITEMLOCATIONDATA: "/item_loc_data/",
  UPDATECOSTANDVAR: "/cost_update_stg_trn/",

  FETCHSTGFIN:"/Retrieve_stg_fin/",
};

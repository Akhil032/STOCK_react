export const CONFIG = {
  BASE_URL: "http://127.0.0.1:8000",
};

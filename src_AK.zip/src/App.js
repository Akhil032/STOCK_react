import Routing from "./routing";

function App() {
  return (
    <>
      <Routing />
    </>
  );
}

export default App;

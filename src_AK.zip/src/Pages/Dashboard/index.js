import * as React from "react";
import WebServices from "../../Components/WebServices";
import Box from "@mui/material/Box";
export default function Index() {
  return <WebServices />;
}

export const errorList = [
  'ITEM is null',
  'Invalid Item',
  'LOCATION is null',
  'Invalid Location',
  'invalid trn_type',
  'TRN_TYPE AREF COMBINATION invalid',
  'QTY is null',
  'invalid currency',
  'invalid location currency combination',
  'trn_date cannot be in future',
]